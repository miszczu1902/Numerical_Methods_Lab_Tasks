from integrals import gauss,gauss_blad,wsp_wielomian
amountOfNodes = 0
print(" 1. e**-x * sin(x)\n"
      " 2. e**-x * cos(x)\n"
      " 3. e**-x * x**3-x**2-2x+1\n"
      " 4. e**-x * 3**x\n"
      " 5. e**-x * |x-1|\n"
      " 6. e**-x * 2*x\n"
      " 0. wyjscie"
      )

menu=8
while menu != 0:
    menu = int(input("wybierz wzor: \n"))
    amountOfNodes=int(input("podaj liczbe wezlow: "))
   # stopien=int(input("podaj stopien wielomianu aproksymujacego: \n"))

    if menu >= 1 and menu<=6:
        # epsilon = float(input("podaj dokladnosc: \n"))
        if amountOfNodes>=2 and amountOfNodes<=5:
            blad = abs(float(input("Podaj oczekiwany maksymaly blad aproksymacji: ")))
            stopien_apro = 1
            dokladnosc = True
            while dokladnosc:
                tab_wsp = wsp_wielomian(menu, amountOfNodes, stopien_apro)
                if gauss_blad(menu, stopien_apro, tab_wsp, amountOfNodes) < blad:
                    dokladnosc = False
                else:
                    stopien_apro += 1
            print("Blad aproksymacji: {}".format(gauss_blad(menu, stopien_apro, tab_wsp, amountOfNodes)))
        else:
            print("podaj stopien wielomianu z przedzialu <2;5>")
    else:
        print("podaj liczbe z zakresu")
        menu == 8
